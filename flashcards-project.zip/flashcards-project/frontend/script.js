async function fetchCards() {
    const response = await fetch('http://localhost:3000/cards');
    const cards = await response.json();
    const cardsList = document.getElementById('cards');
    cardsList.innerHTML = '';
    cards.forEach(card => {
        const li = document.createElement('li');
        li.textContent = `${card.question} - ${card.answer}`;
        cardsList.appendChild(li);
    });
}

document.addEventListener('DOMContentLoaded', fetchCards);
