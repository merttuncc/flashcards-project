const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Daha fazla veri içeren kartlar
let cards = [
    {
        id: 1,
        question: "Çarpma İşlemi",
        answer: "Çarpma işlemi, iki sayının çarpılmasıdır.",
        difficulty: "easy",
        tags: ["Matematik", "İşlemler"],
        course: "matematik"
    },
    {
        id: 2,
        question: "Atom",
        answer: "Atom, maddenin en küçük yapı taşıdır.",
        difficulty: "medium",
        tags: ["Kimya", "Yapılar"],
        course: "kimya"
    },
    {
        id: 3,
        question: "Newton'un Üçüncü Yasası",
        answer: "Her etkiye eşit ve zıt bir tepki vardır.",
        difficulty: "hard",
        tags: ["Fizik", "Kuvvet"],
        course: "fizik"
    },
    {
        id: 4,
        question: "Fotosentez",
        answer: "Bitkilerin güneş ışığını kullanarak besin üretmesidir.",
        difficulty: "easy",
        tags: ["Biyoloji", "Bitkiler"],
        course: "biyoloji"
    },
    {
        id: 5,
        question: "Dünya'nın Katmanları",
        answer: "Dünya'nın katmanları; çekirdek, manto ve kabuk olarak ayrılır.",
        difficulty: "medium",
        tags: ["Coğrafya", "Dünya"],
        course: "coğrafya"
    },
    {
        id: 6,
        question: "E=mc²",
        answer: "Enerji ve kütle arasındaki ilişkiyi tanımlar.",
        difficulty: "hard",
        tags: ["Fizik", "Enerji"],
        course: "fizik"
    },
    {
        id: 7,
        question: "İkinci Dünya Savaşı",
        answer: "1939-1945 yılları arasında gerçekleşmiştir.",
        difficulty: "medium",
        tags: ["Tarih", "Savaşlar"],
        course: "tarih"
    },
    {
        id: 8,
        question: "Organik Bileşikler",
        answer: "Karbon atomu içeren bileşiklerdir.",
        difficulty: "medium",
        tags: ["Kimya", "Organik Kimya"],
        course: "kimya"
    },
    {
        id: 9,
        question: "Fransız Devrimi",
        answer: "1789'da Fransa'da gerçekleşen toplumsal ve siyasal bir devrimdir.",
        difficulty: "hard",
        tags: ["Tarih", "Devrimler"],
        course: "tarih"
    },
    {
        id: 10,
        question: "DNA",
        answer: "Genetik bilgiyi taşıyan moleküldür.",
        difficulty: "easy",
        tags: ["Biyoloji", "Genetik"],
        course: "biyoloji"
    }
];

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Tüm kartları getir
app.get('/cards', (req, res) => {
    res.json(cards);
});

// Yeni kart ekle
app.post('/cards', (req, res) => {
    const newCard = { id: cards.length + 1, ...req.body };
    cards.push(newCard);
    res.status(201).json(newCard);
});

// Kart düzenle
app.put('/cards/:id', (req, res) => {
    const { id } = req.params;
    const updatedCard = { ...req.body, id: parseInt(id) };
    cards = cards.map(card => card.id === parseInt(id) ? updatedCard : card);
    res.json(updatedCard);
});

// Kart sil
app.delete('/cards/:id', (req, res) => {
    const { id } = req.params;
    cards = cards.filter(card => card.id !== parseInt(id));
    res.status(204).send();
});

// Sunucuyu başlat
app.listen(PORT, () => {
    console.log(`API is running on http://localhost:${PORT}`);
});
